
# CISC7204 Assignment 02
# Module 04 Lab 04
# Flight Delay Time Statistics Dashboard

# Task 1: Import required libraries
import pandas as pd
import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.express as px

# Task 1: Read airline dataset
airline_data = pd.read_csv(
    'https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv',
    encoding='ISO-8859-1',
    dtype={
        'Div1Airport': str,
        'Div1TailNum': str,
        'Div2Airport': str,
        'Div2TailNum': str
    }
)

# Task 2: Create Dash application
app = dash.Dash(__name__)

# Task 2 and 3: Build the application layout
app.layout = html.Div(children=[

    # Application title
    html.H1(
        'Flight Details Statistics Dashboard',
        style={
            'textAlign': 'center',
            'color': '#503D36',
            'fontSize': 35
        }
    ),

    # Year input
    html.Div(
        [
            'Input Year: ',
            dcc.Input(
                id='input-year',
                value=2010,
                type='number',
                min=2010,
                max=2020,
                step=1,
                style={
                    'height': '35px',
                    'fontSize': 30
                }
            )
        ],
        style={'fontSize': 30}
    ),

    html.Br(),
    html.Br(),

    # Segment 1: Carrier delay and Weather delay
    html.Div(
        [
            html.Div(
                dcc.Graph(id='carrier-plot'),
                style={'width': '50%'}
            ),

            html.Div(
                dcc.Graph(id='weather-plot'),
                style={'width': '50%'}
            )
        ],
        style={'display': 'flex'}
    ),

    # Segment 2: NAS delay and Security delay
    html.Div(
        [
            html.Div(
                dcc.Graph(id='nas-plot'),
                style={'width': '50%'}
            ),

            html.Div(
                dcc.Graph(id='security-plot'),
                style={'width': '50%'}
            )
        ],
        style={'display': 'flex'}
    ),

    # Segment 3: Late aircraft delay
    html.Div(
        dcc.Graph(id='late-plot'),
        style={'width': '65%'}
    )

])


# Task 4: Compute average delays
def compute_info(airline_data, entered_year):

    # Select data for the entered year
    df = airline_data[
        airline_data['Year'] == int(entered_year)
    ]

    # Average carrier delay
    avg_car = df.groupby(
        ['Month', 'Reporting_Airline']
    )['CarrierDelay'].mean().reset_index()

    # Average weather delay
    avg_weather = df.groupby(
        ['Month', 'Reporting_Airline']
    )['WeatherDelay'].mean().reset_index()

    # Average NAS delay
    avg_NAS = df.groupby(
        ['Month', 'Reporting_Airline']
    )['NASDelay'].mean().reset_index()

    # Average security delay
    avg_sec = df.groupby(
        ['Month', 'Reporting_Airline']
    )['SecurityDelay'].mean().reset_index()

    # Average late aircraft delay
    avg_late = df.groupby(
        ['Month', 'Reporting_Airline']
    )['LateAircraftDelay'].mean().reset_index()

    return avg_car, avg_weather, avg_NAS, avg_sec, avg_late


# Task 5: Callback decorator with five outputs
@app.callback(
    [
        Output('carrier-plot', 'figure'),
        Output('weather-plot', 'figure'),
        Output('nas-plot', 'figure'),
        Output('security-plot', 'figure'),
        Output('late-plot', 'figure')
    ],
    Input('input-year', 'value')
)
def get_graph(entered_year):

    # Handle empty or invalid input
    if (
        entered_year is None
        or entered_year < 2010
        or entered_year > 2020
        or int(entered_year) != entered_year
    ):
        return [
            px.line(title='Please enter a year from 2010 to 2020')
            for _ in range(5)
        ]

    # Compute average delay statistics
    avg_car, avg_weather, avg_NAS, avg_sec, avg_late = (
        compute_info(airline_data, entered_year)
    )

    # 1. Carrier delay chart
    carrier_fig = px.line(
        avg_car,
        x='Month',
        y='CarrierDelay',
        color='Reporting_Airline',
        title='Average carrier delay time (minutes) by airline'
    )

    # 2. Weather delay chart
    weather_fig = px.line(
        avg_weather,
        x='Month',
        y='WeatherDelay',
        color='Reporting_Airline',
        title='Average weather delay time (minutes) by airline'
    )

    # 3. NAS delay chart
    nas_fig = px.line(
        avg_NAS,
        x='Month',
        y='NASDelay',
        color='Reporting_Airline',
        title='Average NAS delay time (minutes) by airline'
    )

    # 4. Security delay chart
    sec_fig = px.line(
        avg_sec,
        x='Month',
        y='SecurityDelay',
        color='Reporting_Airline',
        title='Average security delay time (minutes) by airline'
    )

    # 5. Late aircraft delay chart
    late_fig = px.line(
        avg_late,
        x='Month',
        y='LateAircraftDelay',
        color='Reporting_Airline',
        title='Average late aircraft delay time (minutes) by airline'
    )

    # Return five figures in the output order
    return [
        carrier_fig,
        weather_fig,
        nas_fig,
        sec_fig,
        late_fig
    ]


# Task 6: Run application
if __name__ == '__main__':
    app.run(port=8050)
