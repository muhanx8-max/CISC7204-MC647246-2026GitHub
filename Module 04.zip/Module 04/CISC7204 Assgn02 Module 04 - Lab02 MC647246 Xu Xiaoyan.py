
# Module 04 - Lab 02
# Dash Basics - HTML and Core Components

# Task 1: Import required libraries
import pandas as pd
import plotly.express as px
import dash
from dash import dcc, html

# Task 1: Read the airline dataset
airline_data = pd.read_csv(
    'https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv',
    encoding='ISO-8859-1',
    dtype={
        'Div1Airport': str,
        'Div1TailNum': str,
        'Div2Airport': str,
        'Div2TailNum': str
    }
)

# Task 1: Sample 500 random rows
data = airline_data.sample(n=500, random_state=42)

# Task 1: Create a pie chart
fig = px.pie(
    data,
    values='Flights',
    names='DistanceGroup',
    title='Distance group proportion by flights'
)

# Task 2: Create the Dash application
app = dash.Dash(__name__)

# Task 3-5: Build the application layout
app.layout = html.Div(
    children=[
        # Task 3: Application title
        html.H1(
            'Airline On-time Performance Dashboard',
            style={
                'textAlign': 'center',
                'color': '#503D36',
                'fontSize': 50
            }
        ),

        # Task 4: Application description
        html.P(
            'Proportion of distance group (250 mile distance interval group) by flights.',
            style={
                'textAlign': 'center',
                'color': '#F57241'
            }
        ),

        # Task 5: Add the pie chart
        dcc.Graph(figure=fig)
    ]
)

# Task 6: Run the application
if __name__ == '__main__':
    app.run(port=8050)
