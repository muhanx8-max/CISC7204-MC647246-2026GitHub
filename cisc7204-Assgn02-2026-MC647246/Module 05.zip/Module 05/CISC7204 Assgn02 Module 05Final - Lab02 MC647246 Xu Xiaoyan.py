"""CISC7204 Assignment 02 — Module 05 Final Lab 02.
Automobile sales dashboard: yearly and recession-period statistics.
Run: python DV0101EN_Final_Assign_Part_2_Questions.py
"""
import pandas as pd
import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.express as px

DATA_URL = ('https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/'
            'IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/'
            'historical_automobile_sales.csv')
data = pd.read_csv(DATA_URL)
app = dash.Dash(__name__)
app.title = 'Automobile Sales Statistics Dashboard'

# TASK 2.1 — meaningful dashboard title
# TASK 2.2 — two dropdown menus
dropdown_options = [
    {'label': 'Yearly Statistics', 'value': 'Yearly Statistics'},
    {'label': 'Recession Period Statistics', 'value': 'Recession Period Statistics'},
]
year_list = list(range(1980, 2014))

app.layout = html.Div([
    html.H1('Automobile Sales Statistics Dashboard',
            style={'textAlign': 'center', 'color': '#503D36', 'fontSize': 24}),
    html.Div([
        html.Label('Select Statistics:'),
        dcc.Dropdown(id='dropdown-statistics', options=dropdown_options,
                     value=None, placeholder='Select a report type',
                     style={'width': '80%', 'padding': '3px', 'fontSize': 20}),
    ]),
    html.Div([
        html.Label('Select Year:'),
        dcc.Dropdown(id='select-year',
                     options=[{'label': str(y), 'value': y} for y in year_list],
                     value=None, placeholder='Select year',
                     style={'width': '80%', 'padding': '3px', 'fontSize': 20}),
    ]),
    # TASK 2.3 — division for output
    html.Div(id='output-container', className='chart-grid',
             style={'display': 'flex', 'flexDirection': 'column', 'gap': '16px'}),
], style={'padding': '16px'})

# TASK 2.4 — enable years only for Yearly Statistics
@app.callback(Output('select-year', 'disabled'),
              Input('dropdown-statistics', 'value'))
def update_input_container(selected_statistics):
    if selected_statistics == 'Yearly Statistics':
        return False
    return True


def rows_of_charts(a, b, c, d):
    """Present four charts in two rows of two."""
    return [
        html.Div(className='chart-item', children=[
            html.Div(a, style={'flex': '1', 'minWidth': 0}),
            html.Div(b, style={'flex': '1', 'minWidth': 0}),
        ], style={'display': 'flex', 'gap': '12px'}),
        html.Div(className='chart-item', children=[
            html.Div(c, style={'flex': '1', 'minWidth': 0}),
            html.Div(d, style={'flex': '1', 'minWidth': 0}),
        ], style={'display': 'flex', 'gap': '12px'}),
    ]


# TASK 2.4–2.6 — update the charts when report type/year changes
@app.callback(Output('output-container', 'children'),
              [Input('dropdown-statistics', 'value'),
               Input('select-year', 'value')])
def update_output_container(selected_statistics, input_year):
    if selected_statistics == 'Recession Period Statistics':
        recession_data = data[data['Recession'] == 1]
        # TASK 2.5 Plot 1: annual average automobile sales during recessions
        yearly_rec = recession_data.groupby('Year')['Automobile_Sales'].mean().reset_index()
        r_chart1 = dcc.Graph(figure=px.line(yearly_rec, x='Year', y='Automobile_Sales',
                                            title='Average Automobile Sales During Recession (Year-wise)'))
        # Plot 2: average sales by vehicle type during recessions
        average_sales = recession_data.groupby('Vehicle_Type')['Automobile_Sales'].mean().reset_index()
        r_chart2 = dcc.Graph(figure=px.bar(average_sales, x='Vehicle_Type', y='Automobile_Sales',
                                           title='Average Vehicles Sold by Vehicle Type During Recession'))
        # Plot 3: advertising expenditure by vehicle type
        exp_rec = recession_data.groupby('Vehicle_Type')['Advertising_Expenditure'].sum().reset_index()
        r_chart3 = dcc.Graph(figure=px.pie(exp_rec, values='Advertising_Expenditure',
                                           names='Vehicle_Type',
                                           title='Advertising Expenditure by Vehicle Type During Recession'))
        # Plot 4: unemployment and vehicle type, colored by vehicle type
        unemp_data = recession_data.groupby(['unemployment_rate', 'Vehicle_Type'])['Automobile_Sales'].mean().reset_index()
        r_chart4 = dcc.Graph(figure=px.bar(unemp_data, x='unemployment_rate', y='Automobile_Sales',
                                           color='Vehicle_Type',
                                           labels={'unemployment_rate': 'Unemployment Rate',
                                                   'Automobile_Sales': 'Average Automobile Sales'},
                                           title='Effect of Unemployment Rate on Vehicle Type and Sales'))
        return rows_of_charts(r_chart1, r_chart2, r_chart3, r_chart4)

    elif selected_statistics == 'Yearly Statistics' and input_year is not None:
        yearly_data = data[data['Year'] == int(input_year)]
        # TASK 2.6 Plot 1: full period average annual sales
        yas = data.groupby('Year')['Automobile_Sales'].mean().reset_index()
        y_chart1 = dcc.Graph(figure=px.line(yas, x='Year', y='Automobile_Sales',
                                            title='Yearly Automobile Sales (Whole Period)'))
        # Plot 2: monthly totals in selected year
        mas = yearly_data.groupby('Month')['Automobile_Sales'].sum().reset_index()
        y_chart2 = dcc.Graph(figure=px.line(mas, x='Month', y='Automobile_Sales',
                                            title=f'Total Monthly Automobile Sales in {input_year}'))
        # Plot 3: average sales by type in selected year
        avr_vdata = yearly_data.groupby('Vehicle_Type')['Automobile_Sales'].mean().reset_index()
        y_chart3 = dcc.Graph(figure=px.bar(avr_vdata, x='Vehicle_Type', y='Automobile_Sales',
                                            title=f'Average Vehicles Sold by Vehicle Type in {input_year}'))
        # Plot 4: advertising spend by type in selected year
        exp_data = yearly_data.groupby('Vehicle_Type')['Advertising_Expenditure'].sum().reset_index()
        y_chart4 = dcc.Graph(figure=px.pie(exp_data, values='Advertising_Expenditure',
                                            names='Vehicle_Type',
                                            title='Total Advertisement Expenditure for Each Vehicle'))
        return rows_of_charts(y_chart1, y_chart2, y_chart3, y_chart4)
    return []


if __name__ == '__main__':
    app.run(port=8054, debug=False)
