# CISC7204 Assignment 02 - Module 05 Practice Project Part 02
# Australia Wildfire Dashboard

import pandas as pd
import dash
from dash import html, dcc
from dash.dependencies import Input, Output
import plotly.express as px

# Read the wildfire dataset
DATA_URL = ('https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/'
            'IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/Historical_Wildfires.csv')
df = pd.read_csv(DATA_URL)

# Extract month names and year from the date column
parsed_dates = pd.to_datetime(df['Date'])
df['Month'] = parsed_dates.dt.month_name()
df['Year'] = parsed_dates.dt.year

app = dash.Dash(__name__)

# Task 2.1-2.3: Title, inputs, and two graph containers
app.layout = html.Div(children=[
    html.H1('Australia Wildfire Dashboard', style={
        'textAlign': 'center', 'color': '#503D36', 'fontSize': 26
    }),
    html.Div([
        html.Div([
            html.H2('Select Region:', style={'marginRight': '2em'}),
            dcc.RadioItems(
                options=[
                    {'label': 'New South Wales', 'value': 'NSW'},
                    {'label': 'Northern Territory', 'value': 'NT'},
                    {'label': 'Queensland', 'value': 'QL'},
                    {'label': 'South Australia', 'value': 'SA'},
                    {'label': 'Tasmania', 'value': 'TA'},
                    {'label': 'Victoria', 'value': 'VI'},
                    {'label': 'Western Australia', 'value': 'WA'},
                ],
                value='NSW', id='region', inline=True
            ),
            html.Div([
                html.H2('Select Year:', style={'marginRight': '2em'}),
                dcc.Dropdown(
                    options=[{'label': str(y), 'value': int(y)} for y in sorted(df['Year'].dropna().unique()) if 2005 <= y <= 2020],
                    value=2005, id='year', clearable=False
                )
            ]),
        ]),
        html.Div([
            html.Div([], id='plot1'),
            html.Div([], id='plot2'),
        ], style={'display': 'flex', 'gap': '12px', 'flexWrap': 'wrap'}),
    ]),
])

# Task 2.4: Two inputs and two outputs
@app.callback(
    [Output(component_id='plot1', component_property='children'),
     Output(component_id='plot2', component_property='children')],
    [Input(component_id='region', component_property='value'),
     Input(component_id='year', component_property='value')]
)
def reg_year_display(input_region, input_year):
    # Task 2.5: Filter by region and year
    region_data = df[df['Region'] == input_region]
    y_r_data = region_data[region_data['Year'] == input_year]

    # Chart 1: monthly average estimated fire area
    est_data = y_r_data.groupby('Month', as_index=False)['Estimated_fire_area'].mean()
    fig1 = px.pie(
        est_data, values='Estimated_fire_area', names='Month',
        title='{} : Monthly Average Estimated Fire Area in year {}'.format(input_region, input_year)
    )

    # Chart 2: monthly average count of vegetation-fire pixels
    veg_data = y_r_data.groupby('Month', as_index=False)['Count'].mean()
    fig2 = px.bar(
        veg_data, x='Month', y='Count',
        title='{} : Average Count of Pixels for Presumed Vegetation Fires in year {}'.format(input_region, input_year)
    )
    return dcc.Graph(figure=fig1, style={'minWidth': '420px', 'flex': '1'}), dcc.Graph(figure=fig2, style={'minWidth': '420px', 'flex': '1'})


if __name__ == '__main__':
    app.run(port=8053)
